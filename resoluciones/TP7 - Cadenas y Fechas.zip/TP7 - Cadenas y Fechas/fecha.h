#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "cadena.h"



void fGetNow(char date[]);
int fGetAnioLarge(char date[]);
int fGetAnioShort(char date[]);
int fGetMonthNumber(char date[]);
void fGetMonthLarge(char date[],char month[]);
void fGetMonthLargeTernario(char date[],char month[]);
void fGetMonthShort(char date[],char month[]);
int fGetDayNumber(char date[]);
int fGetDayOfWeek(char date[]);
void fGetDayLarge(char date[],char day[]);
void fGetDayShort(char date[],char day[]);
int fGetHour(char date[]);
int fGetMinute(char date[]);

#endif // FECHA_H_INCLUDED

/**
Es reemplazado
%a 	por la abreviatura del nombre del d�a de la semana de la localidad
%A 	por el nombre completo del d�a de la semana de la localidad
%b 	por la abreviatura del nombre del mes de la localidad
%B 	por el nombre completo del mes de la localidad
%c 	por la fecha apropiada y la representaci�n de la hora de la localidad
%d 	por el d�a del mes como un n�mero decimal (01-31)
%H 	por la hora (reloj de 24 horas) como un n�mero decimal (00-23)
%I 	por la hora (reloj de 12 horas) como un n�mero decimal (01-12)
%j 	por el d�a del a�o como un n�mero decimal (001-366)
%m 	por el mes como un n�mero decimal (01-12)
%M 	por el minuto como un n�mero decimal (00-59)
%p 	por el equivalente de la localidad de las designaciones de AM/PM asociadas con un reloj de 12 horas
%S 	por el segundo como un n�mero decimal (00-61)
%U 	por el n�mero de la semana del a�o (el primer Domingo como el primer d�a de la semana 1) como un n�mero decimal (00-53)
%w 	por el d�a de la semana como un n�mero decimal (0-6), donde Domingo es 0
%W 	por el n�mero de la semana del a�o (el primer Lunes como el primer d�a de la semana 1) como un n�mero decimal (00-53)
%x 	por la representaci�n apropiada de la fecha de la localidad
%X 	por la representaci�n apropiada de la hora de la localidad
%y 	por el a�o sin siglo como un n�mero decimal (00-99)
%Y 	por el a�o con siglo como un n�mero decimal
%Z 	por el nombre o la abreviatura del huso horario, o por ningunos caracteres si ning�n huso horario es determinable
%% 	por %

*/
