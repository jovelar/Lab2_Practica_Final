
#include "fecha.h"

const char* monthsLarge[]={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
const char* daysLarge[]={"Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"};

void fGetNow(char date[]){
    time_t tiempo = time(0);
    struct tm *tlocal = localtime(&tiempo);
    strftime(date,128,"%Y-%m-%d-%w %H:%M:%S",tlocal);
}

int fGetAnioLarge(char date[]){
    char anio[5];
    int anioNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=0;i<5;i++){
            anio[i]=date[i];
        }
        anio[i+1]='\0';
        anioNumber=atoi(anio);
    }
    return anioNumber;
}

int fGetAnioShort(char date[]){
    char anio[3];
    int anioNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=2;i<5;i++){
            anio[i-2]=date[i];
        }
        anio[i-1]='\0';
        anioNumber=atoi(anio);
    }
    return anioNumber;
}

int fGetMonthNumber(char date[]){
    char month[3];
    int monthNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=5;i<8;i++){
            month[i-5]=date[i];
        }
        month[i-5]='\0';
        monthNumber=atoi(month);
    }
    return monthNumber;
}

void fGetMonthLarge(char date[],char month[]){
    if(strlen(date)>0){
        strcpy(month,monthsLarge[fGetMonthNumber(date)-1]);
    }
}

void fGetMonthLargeTernario(char date[],char month[]){
    (strlen(date)>0)?strcpy(month,monthsLarge[fGetMonthNumber(date)-1]):0;
}

void fGetMonthShort(char date[],char month[]){
    if(strlen(date)>0){
        fStrStr(monthsLarge[fGetMonthNumber(date)-1],month,0,3);
    }
}

int fGetDayNumber(char date[]){
    char day[3];
    int dayNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=8;i<10;i++){
            day[i-8]=date[i];
        }
        day[i-8]='\0';
        dayNumber=atoi(day);
    }
    return dayNumber;
}

int fGetDayOfWeek(char date[]){
    char day[2];
    int dayNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=11;i<12;i++){
            day[i-11]=date[i];
        }
        day[i-11]='\0';
        dayNumber=atoi(day);
    }
    return dayNumber;
}

void fGetDayLarge(char date[],char day[]){
    if(strlen(date)>0){
        strcpy(day,daysLarge[fGetDayOfWeek(date)]);
    }
}

void fGetDayShort(char date[],char day[]){
    if(strlen(date)>0){
        fStrStr(daysLarge[fGetDayOfWeek(date)],day,0,3);
    }
}

int fGetHour(char date[]){
    char hour[3];
    int hourNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=13;i<15;i++){
            hour[i-13]=date[i];
        }
        hour[i-13]='\0';
        hourNumber=atoi(hour);
    }
    return hourNumber;
}

int fGetMinute(char date[]){
    char minute[3];
    int minuteNumber=0;
    int i;
    if(strlen(date)>0){
        for(i=16;i<18;i++){
            minute[i-16]=date[i];
        }
        minute[i-16]='\0';
        minuteNumber=atoi(minute);
    }
    return minuteNumber;
}

