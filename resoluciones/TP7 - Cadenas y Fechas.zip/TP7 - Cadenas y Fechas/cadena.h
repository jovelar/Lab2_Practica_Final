#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void fStrDelPosChar(char c[], int pos);                /// Elimina el caracter ubicado en la posicion dada
void fStrLTrim(char c[]);                              /// Elimina espacios en blanco a la izquierda de la cadena
void fStrRTrim(char c[]);                              /// Elimina espacios en blanco a la derecha de la cadena
void fStrAllTrim(char c[]);                            /// Elimina todos los espacios en blanco de la cadena
void fStrDelete(char c[]);                             /// Elimina el contenido de la cadena
void fStrToUpper(char c[]);                            /// Convierte la cadena en mayusculas
void fStrToLower(char c[]);                            /// Convierte la cadena en minusculas
void fStrToUpperFirst(char c[]);                       /// Convierte la primera letra de la cadena en mayuscula
void fStrToUpperAllFirstLetters(char c[]);             /// Convierte la primera letra de cada palabra en mayuscula
void fStrFirstCharReplace(char c[], char o, char r);   /// Reemplaza la primer ocurrencia de un caracter dado por otro
void fStrAllCharReplace(char c[], char o, char r);     /// Reemplaza todas las ocurrencias de un caracter dado por otro
int fStrFindChar(char c[], char f);                    /// Busca un caracter en la cadena, retorna la posicion
void fStrDelFirstChar(char c[], char e);               /// Elimina la primer ocurrencia de un char
void fStrDelAllChar(char c[], char e);                 /// Elimina todas las ocurrencias de un char
void fStrReplace(char c[], char r, int pos);
void fStrStr(char o[], char d[], int desde, int cant);

#endif // CADENA_H_INCLUDED
