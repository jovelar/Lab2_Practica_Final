#include "cadena.h"

void fStrDelPosChar(char c[], int pos){
    int v = strlen(c) - 1;
    int i;
    for(i=pos;i<v;i++){
        c[i]=c[i+1];
    }
    c[i]='\0';
}

void fStrLTrim(char c[]){
    int flag = 0;
    int i = 0;
    int v = strlen(c);
    while((i < v) && (flag == 0)){
        if(isblank(c[i])){
            fStrDelPosChar(c,i);
            v--;
        }else{
            flag=1;
        }
    }
}

void fStrRTrim(char c[]){
    int flag = 0;
    int v = strlen(c);
    int i = v - 1;
    while((i >=0 ) && (flag == 0)){
        if(isblank(c[i])){
            c[i]='\0';
        }else{
            flag = 1;
        }
        i--;
    }
}

void fStrAllTrim(char c[]){
    int v = strlen(c);
    int i = v - 1;
    while(i >= 0){
        if(isblank(c[i])){
            fStrDelPosChar(c,i);
        }
        i--;
    }
}

void fStrDelete(char c[]){
    c[0]='\0';
}

void fStrToUpper(char c[]){
    for(int i=0;i<strlen(c);i++){
        c[i]=toupper(c[i]);
    }
}

void fStrToLower(char c[]){
    for(int i=0;i<strlen(c);i++){
        c[i]=tolower(c[i]);
    }
}

void fStrToUpperFirst(char c[]){
    if(strlen(c) > 0){
        c[0] = (isalpha(c[0]))?toupper(c[0]):c[0];
    }
}

void fStrToUpperAllFirstLetters(char c[]){
    fStrToUpperFirst(c);
    for(int i=0; i < strlen(c)-1; i++){
        if(isblank(c[i])){
            c[i+1] = (isalpha(c[i+1]))?toupper(c[i+1]):c[i+1];
        }
    }
}

void fStrFirstCharReplace(char c[], char o, char r){
    int i=0;
    int flag=0;
    while((i<strlen(c))&&(flag==0)){
        if(c[i]==o){
            c[i]=r;
            flag=1;
        }
        i++;
    }
}

void fStrAllCharReplace(char c[], char o, char r){
    for(int i=0;i<strlen(c);i++){
        c[i]=(c[i]==o)?r:c[i];
    }
}

int fStrFindChar(char c[], char f){
    int i=0;
    int flag=-1;
    while((i<strlen(c))&&(flag==-1)){
        if(c[i]==f){
            flag=i;
        }
        i++;
    }
    return flag;
}

void fStrDelFirstChar(char c[], char e){
    int flag = 0;
    int i = 0;
    int v = strlen(c);
    while((i < v) && (flag == 0)){
        if(c[i]==e){
            fStrDelPosChar(c,i);
            flag = 1;
        }
        i++;
    }
}

void fStrDelAllChar(char c[], char e) {
    int v = strlen(c);
    int i = 0;
    while(i < v){
        if(c[i]==e){
            fStrDelPosChar(c,i);
            v--;
        }
        i++;
    }
}

void fStrReplace(char c[], char r, int pos){
    c[pos] = r;
}

void fStrStr(char o[], char d[], int desde, int cant){
    int i;
    if(strlen(o)>=(desde+cant)){
        for(i=desde;i<(desde+cant)-1;i++){
            d[i-desde]=o[i];
        }
       d[i-desde+1]='\0';
    }
}

