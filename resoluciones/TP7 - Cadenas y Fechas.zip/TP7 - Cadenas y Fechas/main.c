#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <strings.h>
#include "utilidades.h"
#include "cadena.h"
//#include "fecha.h"

int main()
{
    srand(time(NULL));

    printf("\t\t\t\t<<< FUNCIONES DE FECHA >>>\n\n");
    replicante('_',110);
    char date[128];         /// Variable usada para almacenar una cadena Fecha y hora
    fGetNow(date);          /// Genera una cadena con la fecha y hora del sistema
    printf("\nFuncion fGetNow() - Genera una cadena con la fecha y hora del sistema: %s\n",date);
    replicante('_',110);

    int anio;
    anio = fGetAnioLarge(date); /// Devuelve el a�o en formato yyyy
    printf("\nFuncion fGetAnioLarge() - Devuelve el a%co en formato yyyy: %d\n",164,anio);
    replicante('_',110);

    anio = fGetAnioShort(date); /// Devuelve el a�o en formato yy
    printf("\nFuncion fGetAnioShort() - Devuelve el a%co en formato yy: %d\n",164,anio);
    replicante('_',110);

    int month;
    month = fGetMonthNumber(date); /// Devuelve el numero de mes
    printf("\nFuncion fGetMonthNumber() - Devuelve el numero de mes: %d\n",month);
    replicante('_',110);

    char monthChar[20];
    fGetMonthLargeTernario(date,monthChar); /// Devuelve el mes en caracteres - Formato completo
    printf("\nFuncion fGetMonthLarge() - Devuelve el mes en caracteres - Formato completo: %s\n",monthChar);
    replicante('_',110);

    fGetMonthShort(date,monthChar); /// Devuelve el mes en caracteres - Formato corto
    printf("\nFuncion fGetMonthShort() - Devuelve el mes en caracteres - Formato corto: %s\n",monthChar);
    replicante('_',110);

    int day;
    day = fGetDayNumber(date); /// Devuelve el numero de dia
    printf("\nFuncion fGetDayNumber() - Devuelve el numero de dia: %d\n",day);
    replicante('_',110);

    int dow;
    dow = fGetDayOfWeek(date); /// Devuelve el numero de dia de la semana comenzando en Domingo
    printf("\nFuncion fGetDayOfWeek() - Devuelve el numero de dia de la semana comenzando en 0 Domingo: %d\n",dow);
    replicante('_',110);

    char dayOfWeek[20];
    fGetDayLarge(date,dayOfWeek); /// Devuelve el dia de semana en caracteres - Formato completo
    printf("\nFuncion fGetDayLarge() - Devuelve el dia de semana en caracteres - Formato completo: %s\n",dayOfWeek);
    replicante('_',110);

    fGetDayShort(date,dayOfWeek); /// Devuelve el dia de semana en caracteres - Formato corto
    printf("\nFuncion fGetDayShort() - Devuelve el dia de semana en caracteres - Formato corto: %s\n",dayOfWeek);
    replicante('_',110);

    int hour;
    hour = fGetHour(date); /// Devuelve la hora
    printf("\nFuncion fGetHour() - Devuelve la hora: %d\n",hour);
    replicante('_',110);

    int minute;
    minute = fGetMinute(date); /// Devuelve los minutos
    printf("\nFuncion fGetMinute() - Devuelve los minutos: %d\n",minute);
    replicante('_',110);

    printf("\n");
    printf("\t\t\t\t<<< FUNCIONES DE STRING >>>\n\n");
    char frase[]="    texto para probar     LAS FUNCIONES DE CADENA     ";

    printf("\nFuncion fStrLTrim() - Elimina espacios en blanco a la izquierda de la cadena");
    printf("\nCadena Original......: %s",frase);
    fStrLTrim(frase);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"    texto para probar     LAS FUNCIONES DE CADENA     ");
    printf("\nFuncion fStrRTrim() - Elimina espacios en blanco a la derecha de la cadena");
    printf("\nCadena Original......: %sfin",frase);
    fStrRTrim(frase);
    printf("\nCadena Modificada....: %sfin\n",frase);
    replicante('_',110);

    strcpy(frase,"    texto para probar     LAS FUNCIONES DE CADENA     ");
    printf("\nFuncion fStrAllTrim() - Elimina espacios en blanco en toda la cadena");
    printf("\nCadena Original......: %sfin",frase);
    fStrAllTrim(frase);
    printf("\nCadena Modificada....: %sfin\n",frase);
    replicante('_',110);

    strcpy(frase,"    texto para probar     LAS FUNCIONES DE CADENA     ");
    printf("\nFuncion fStrDelete() - Elimina el contenido de la cadena");
    printf("\nCadena Original......: %s",frase);
    fStrDelete(frase);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);


    strcpy(frase,"    texto para probar     LAS FUNCIONES DE CADENA     ");
    printf("\nFuncion fStrToUpper() - Convierte toda la cadena a mayusculas");
    printf("\nCadena Original......: %s",frase);
    fStrToUpper(frase);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"    texto para probar     LAS FUNCIONES DE CADENA     ");
    printf("\nFuncion fStrToLower() - Convierte toda la cadena a minusculas");
    printf("\nCadena Original......: %s",frase);
    fStrToLower(frase);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto para probar     LAS FUNCIONES DE CADENA     ");
    printf("\nFuncion fStrToUpperFirst() - Convierte a mayuscula la primer letra de la cadena");
    printf("\nCadena Original......: %s",frase);
    fStrToUpperFirst(frase);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto para probar     las funciones de cadena    ");
    printf("\nFuncion fStrToUpperAllFirstLetters() - Convierte a mayuscula la primer letra de cada palabra de la cadena");
    printf("\nCadena Original......: %s",frase);
    fStrToUpperAllFirstLetters(frase);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto para probar     mas funciones de cadena    ");
    printf("\nFuncion fStrFirstCharReplace() - Reemplaza la primer ocurrencia encontrada por otra");
    printf("\nCadena Original......: %s",frase);
    fStrFirstCharReplace(frase,'m','l');
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto para probar     mas funciones de cadena    ");
    printf("\nFuncion fStrFirstCharReplace() - Reemplaza la primer ocurrencia encontrada por otra");
    printf("\nCadena Original......: %s",frase);
    fStrFirstCharReplace(frase,'m','l');
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto pzrz probzr     mzs funciones de czdenz    ");
    printf("\nFuncion fStrFirstCharReplace() - Reemplaza todas las ocurrencias encontradas por otra");
    printf("\nCadena Original......: %s",frase);
    fStrAllCharReplace(frase,'x','a');
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    int e;
    strcpy(frase,"texto para probar     mas funciones de cadena    ");
    printf("\nFuncion fStrFindChar() - Busca un caracter y retorna -1 si no lo encuentra o su posicion");
    printf("\nCadena Original......: %s",frase);
    e=fStrFindChar(frase,'x');
    printf("\nLetra buscada: %c, encontrada en posicion....: %d\n",'x',e);
    replicante('_',110);

    strcpy(frase,"texto para probar     mas funciones de cadena    ");
    printf("\nFuncion fStrDelFirstChar() - Elimina la primer ocurrencia de un caracter dado");
    printf("\nCadena Original......: %s",frase);
    fStrDelFirstChar(frase,'a');
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto para probar     mas funciones de cadena    ");
    printf("\nFuncion fStrDelAllChar() - Elimina todas las ocurrencias de un caracter dado");
    printf("\nCadena Original......: %s",frase);
    fStrDelAllChar(frase,'a');
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);

    strcpy(frase,"texto para probar     mas funciones de cadena    ");
    printf("\nFuncion fStrReplace() - Reemplaza el caracter de una posicion por otro");
    printf("\nCadena Original......: %s",frase);
    fStrReplace(frase,'a',5);
    printf("\nCadena Modificada....: %s\n",frase);
    replicante('_',110);


    printf("\n");
    return 0;
}
